import torch
from transformers import RobertaTokenizer, RobertaForSequenceClassification
import numpy as np
import pandas as pd
import json
import os
from utils.password_analyzer import calculate_entropy, estimate_brute_force_time

# Load configuration
with open('config.json') as f:
    config = json.load(f)

class PasswordStrengthDetector:
    def __init__(self, model_path=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
        
        try:
            if model_path and os.path.exists(model_path):
                print(f"Loading model from local path: {model_path}")
                self.model = RobertaForSequenceClassification.from_pretrained(model_path)
            else:
                print("Loading default RoBERTa-base model from Hugging Face")
                self.model = RobertaForSequenceClassification.from_pretrained(
                    "roberta-base", 
                    num_labels=3,
                    local_files_only=False
                )
        except Exception as e:
            print(f"Error loading model: {e}")
            print("Falling back to rule-based assessment")
            self.model = None
        
        self.labels = {0: "Weak", 1: "Medium", 2: "Strong"}
        self.common_passwords = self._load_common_passwords()

    def _load_common_passwords(self):
        common_path = os.path.join('data', 'common_passwords.txt')
        if os.path.exists(common_path):
            with open(common_path) as f:
                return set(line.strip() for line in f)
        return set()

    def predict_strength(self, password):
        """Predict password strength with exact requirements"""
        # First check length requirement
        if len(password) < 6 or len(password) > 8:
            return {
                'password': password,
                'strength': "Invalid",
                'confidence': 1.0,
                'probabilities': {'Weak': 0.0, 'Medium': 0.0, 'Strong': 0.0},
                'entropy': calculate_entropy(password),
                'brute_force_time': estimate_brute_force_time(password),
                'feedback': "Password must be 6-8 characters long."
            }
        
        # Rule-based assessment first
        strength, confidence, probabilities = self._exact_rule_based_assessment(password)
        
        # If model exists, blend with model prediction
        if self.model:
            try:
                encoding = self.tokenizer(
                    [password],
                    truncation=True,
                    padding=True,
                    max_length=config["max_length"],
                    return_tensors="pt"
                )
                
                with torch.no_grad():
                    inputs = {
                        'input_ids': encoding['input_ids'].to(self.device),
                        'attention_mask': encoding['attention_mask'].to(self.device)
                    }
                    outputs = self.model(**inputs)
                    logits = outputs.logits
                    model_pred = torch.argmax(logits, dim=1).item()
                    model_probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
                
                # Blend rule-based and model predictions (70% rule, 30% model)
                probabilities = [
                    0.7 * probabilities[0] + 0.3 * model_probs[0],
                    0.7 * probabilities[1] + 0.3 * model_probs[1],
                    0.7 * probabilities[2] + 0.3 * model_probs[2]
                ]
                strength = np.argmax(probabilities)
                confidence = probabilities[strength]
                
            except Exception as e:
                print(f"Model prediction failed: {e}")
        
        entropy = calculate_entropy(password)
        brute_force_time = estimate_brute_force_time(password)
        
        return {
            'password': password,
            'strength': self.labels[strength],
            'confidence': float(confidence),
            'probabilities': {
                'Weak': float(probabilities[0]),
                'Medium': float(probabilities[1]),
                'Strong': float(probabilities[2])
            },
            'entropy': entropy,
            'brute_force_time': brute_force_time,
            'feedback': self._generate_feedback(password, strength, entropy)
        }
    
    def _exact_rule_based_assessment(self, password):
        """Exact rules as specified by user"""
        # Weak passwords (0)
        if (len(password) < 6 or
            password.isnumeric() or
            password.isalpha() or
            password.lower() in self.common_passwords or
            password.lower() == password or
            not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 0, 0.99, [0.99, 0.01, 0.00]
        
        # Strong passwords (2)
        if (any(c.islower() for c in password) and
            any(c.isupper() for c in password) and
            any(c.isdigit() for c in password) and
            any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 2, 0.90, [0.05, 0.05, 0.90]
        
        # Medium passwords (1) - everything else
        return 1, 0.80, [0.10, 0.80, 0.10]
    
    def _generate_feedback(self, password, pred, entropy):
        """Generate feedback based on exact requirements"""
        feedback = []
        
        if pred == 0:  # Weak
            feedback.append("Your password is weak.")
            if password.isnumeric():
                feedback.append("Contains only numbers.")
            elif password.isalpha():
                feedback.append("Contains only letters.")
            elif password.lower() == password:
                feedback.append("No uppercase letters.")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                feedback.append("No special characters.")
        
        elif pred == 1:  # Medium
            feedback.append("Your password is medium strength.")
            missing = []
            if not any(c.islower() for c in password):
                missing.append("lowercase letters")
            if not any(c.isupper() for c in password):
                missing.append("uppercase letters")
            if not any(c.isdigit() for c in password):
                missing.append("numbers")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                missing.append("special characters")
            
            if missing:
                feedback.append(f"Add {' and '.join(missing)} to make it strong.")
        
        else:  # Strong
            feedback.append("Your password is strong!")
        
        return " ".join(feedback)

def main():
    print("Initializing Password Strength Detector...")
    detector = PasswordStrengthDetector(config["model_path"])
    
    print("\nPassword Strength Detection System (6-8 characters only)")
    print("Enter a password to check its strength (or 'quit' to exit):")
    
    test_passwords = [
        "12345", "abcdef", "P@ssw0", "123$ab", 
        "ABC123", "aBc$12", "123$$ABC", "aBc$%123"
    ]
    
    # Test mode (uncomment to verify behavior)
    # print("\nTest Results:")
    # for pwd in test_passwords:
    #     result = detector.predict_strength(pwd)
    #     print(f"\nPassword: {pwd} => {result['strength']}")
    #     print(f"Feedback: {result['feedback']}")
    
    # Interactive mode
    while True:
        password = input("\nPassword: ").strip()
        if password.lower() in ['quit', 'exit']:
            break
        
        result = detector.predict_strength(password)
        
        print("\nResults:")
        print(f"Password: {result['password']}")
        if result['strength'] == "Invalid":
            print(result['feedback'])
            continue
            
        print(f"Strength: {result['strength']} (confidence: {result['confidence']:.2f})")
        print(f"Probabilities - Weak: {result['probabilities']['Weak']:.4f}, Medium: {result['probabilities']['Medium']:.4f}, Strong: {result['probabilities']['Strong']:.4f}")
        print(f"Entropy: {result['entropy']:.2f} bits")
        print("\nEstimated cracking time:")
        for algo, time_est in result['brute_force_time'].items():
            print(f"  {algo}: {time_est}")
        print("\nRecommendations:")
        print(result['feedback'])

if __name__ == "__main__":
    main()