"""
Quick test script to verify the GUI interface works correctly
Run this before using gui_interface.py
"""

import sys
import tkinter as tk

def test_gui_imports():
    """Test if all GUI dependencies are available"""
    print("Testing GUI dependencies...")
    
    try:
        import torch
        print("✓ PyTorch imported successfully")
    except ImportError:
        print("✗ PyTorch not found - run: pip install torch")
        return False
    
    try:
        from transformers import RobertaTokenizer, RobertaForSequenceClassification
        print("✓ Transformers imported successfully")
    except ImportError:
        print("✗ Transformers not found - run: pip install transformers")
        return False
    
    try:
        import numpy
        print("✓ NumPy imported successfully")
    except ImportError:
        print("✗ NumPy not found - run: pip install numpy")
        return False
    
    try:
        print("✓ Tkinter is available")
    except:
        print("✗ Tkinter not found")
        return False
    
    return True

def test_gui_file():
    """Test if gui_interface.py exists and can be imported"""
    print("\nTesting GUI interface file...")
    
    try:
        import gui_interface
        print("✓ gui_interface.py imported successfully")
        return True
    except ImportError as e:
        print(f"✗ Failed to import gui_interface.py: {e}")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_detector_init():
    """Test if detector can be initialized"""
    print("\nTesting detector initialization...")
    
    try:
        import gui_interface
        from gui_interface import PasswordStrengthDetector
        import json
        
        with open('config.json') as f:
            config = json.load(f)
        
        print("Initializing detector (this may take a moment)...")
        detector = PasswordStrengthDetector(config["model_path"])
        print("✓ Detector initialized successfully")
        return detector
    except Exception as e:
        print(f"✗ Failed to initialize detector: {e}")
        return None

def test_password_analysis(detector):
    """Test password analysis with sample passwords"""
    print("\nTesting password analysis...")
    
    test_passwords = [
        ("12345", "Should be Invalid - too short"),
        ("abcdef", "Should be Weak - only letters"),
        ("123456", "Should be Weak - common password"),
        ("P@ssw0", "Should be Strong - has all types")
    ]
    
    for password, expected in test_passwords:
        try:
            result = detector.predict_strength(password)
            strength = result['strength']
            print(f"✓ '{password}' => {strength} ({expected})")
        except Exception as e:
            print(f"✗ Failed to analyze '{password}': {e}")
            return False
    
    return True

def run_gui_test():
    """Test if GUI window can be created"""
    print("\nTesting GUI window creation...")
    
    try:
        root = tk.Tk()
        root.title("Test Window")
        root.geometry("200x100")
        
        label = tk.Label(root, text="GUI test successful!")
        label.pack(pady=20)
        
        # Close window after 1 second
        root.after(1000, root.destroy)
        root.mainloop()
        
        print("✓ GUI window created successfully")
        return True
    except Exception as e:
        print(f"✗ Failed to create GUI window: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("PASSWORD STRENGTH GUI - SYSTEM TEST")
    print("=" * 60)
    
    all_passed = True
    
    # Test imports
    if not test_gui_imports():
        all_passed = False
        print("\n✗ Import tests failed. Install missing dependencies.")
        sys.exit(1)
    
    # Test GUI file
    if not test_gui_file():
        all_passed = False
        print("\n✗ GUI file test failed.")
        sys.exit(1)
    
    # Test detector
    detector = test_detector_init()
    if not detector:
        all_passed = False
        print("\n✗ Detector initialization failed.")
        sys.exit(1)
    
    # Test analysis
    if not test_password_analysis(detector):
        all_passed = False
        print("\n✗ Password analysis tests failed.")
        sys.exit(1)
    
    # Test GUI window
    if not run_gui_test():
        all_passed = False
        print("\n✗ GUI window test failed.")
        sys.exit(1)
    
    print("\n" + "=" * 60)
    print("✓ ALL TESTS PASSED!")
    print("=" * 60)
    print("\nYou can now run the GUI with: python gui_interface.py")

if __name__ == "__main__":
    main()

