import pandas as pd
import random
from tqdm import tqdm

def generate_password(length, complexity):
    """Generate a password with given complexity"""
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    digits = "0123456789"
    symbols = "!@#$%^&*()_+-=[]{};':\",./<>?`~"
    
    if complexity == 0:  # Weak
        chars = lower + digits
        return ''.join(random.choices(chars, k=random.randint(4, 8)))
    elif complexity == 1:  # Medium
        chars = lower + upper + digits
        return ''.join(random.choices(chars, k=random.randint(8, 12)))
    else:  # Strong
        chars = lower + upper + digits + symbols
        return ''.join(random.choices(chars, k=random.randint(12, 16)))

def create_dataset(num_samples=10000, output_file='data/labeled_passwords.csv'):
    """Create a labeled password dataset"""
    data = []
    for _ in tqdm(range(num_samples)):
        strength = random.choices([0, 1, 2], weights=[0.4, 0.3, 0.3])[0]
        password = generate_password(random.randint(4, 16), strength)
        data.append({'password': password, 'strength': strength})
    
    df = pd.DataFrame(data)
    df.to_csv(output_file, index=False)
    print(f"Dataset created with {num_samples} samples at {output_file}")

if __name__ == "__main__":
    create_dataset(50000)  # Create a dataset with 50,000 samples