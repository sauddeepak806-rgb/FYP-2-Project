import torch
from transformers import RobertaTokenizer, RobertaForSequenceClassification
import numpy as np
import pandas as pd
import json
import os
import warnings
import math
import string

# Suppress the specific warning about classifier initialization
warnings.filterwarnings("ignore", message="Some weights of RobertaForSequenceClassification were not initialized from the model checkpoint")

# Load configuration
with open('config.json') as f:
    config = json.load(f)

def calculate_entropy(password):
    """Calculate password entropy in bits"""
    if not password:
        return 0
    
    # Character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()_+-=[]{};':\",./<>?`~"
    
    # Determine character set size
    charset_size = 0
    if any(c in lowercase for c in password):
        charset_size += len(lowercase)
    if any(c in uppercase for c in password):
        charset_size += len(uppercase)
    if any(c in digits for c in password):
        charset_size += len(digits)
    if any(c in special for c in password):
        charset_size += len(special)
    
    if charset_size == 0:
        return 0
    
    # Calculate entropy
    entropy = len(password) * math.log2(charset_size)
    return round(entropy, 2)

def estimate_brute_force_time(password):
    """Estimate brute force attack time for different attack methods"""
    if not password:
        return {"Dictionary": "Instant", "Brute Force": "Instant", "Advanced": "Instant"}
    
    # Character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()_+-=[]{};':\",./<>?`~"
    
    # Determine character set size
    charset_size = 0
    if any(c in lowercase for c in password):
        charset_size += len(lowercase)
    if any(c in uppercase for c in password):
        charset_size += len(uppercase)
    if any(c in digits for c in password):
        charset_size += len(digits)
    if any(c in special for c in password):
        charset_size += len(special)
    
    if charset_size == 0:
        return {"Dictionary": "Instant", "Brute Force": "Instant", "Advanced": "Instant"}
    
    # Calculate combinations
    combinations = charset_size ** len(password)
    
    # Assume 1 billion attempts per second (modern GPU)
    attempts_per_second = 1_000_000_000
    
    # Time estimates
    seconds = combinations / attempts_per_second
    
    if seconds < 1:
        time_str = "Instant"
    elif seconds < 60:
        time_str = f"{seconds:.0f} seconds"
    elif seconds < 3600:
        time_str = f"{seconds/60:.0f} minutes"
    elif seconds < 86400:
        time_str = f"{seconds/3600:.0f} hours"
    elif seconds < 31536000:
        time_str = f"{seconds/86400:.0f} days"
    else:
        time_str = f"{seconds/31536000:.0f} years"
    
    # Dictionary attack (common passwords)
    if len(password) <= 6:
        dict_time = "Seconds to minutes"
    elif len(password) <= 8:
        dict_time = "Minutes to hours"
    else:
        dict_time = "Hours to days"
    
    return {
        "Dictionary Attack": dict_time,
        "Brute Force": time_str,
        "Advanced Attack": f"{time_str} (estimated)"
    }

class PasswordStrengthDetector:
    def __init__(self, model_path=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
        
        # Priority order for model loading
        model_paths = [
            "models/trained_model",  # First priority: trained model
            model_path,               # Second priority: config-specified path
            "models/initialized_model"  # Third priority: initialized model
        ]
        
        self.model = None
        loaded_path = None
        
        for path in model_paths:
            if path and os.path.exists(path) and os.path.isdir(path):
                try:
                    print(f"Loading model from: {path}")
                    self.model = RobertaForSequenceClassification.from_pretrained(path)
                    loaded_path = path
                    print(f"✓ Model loaded successfully from {path}")
                    break
                except Exception as e:
                    print(f"Failed to load from {path}: {e}")
                    continue
        
        # If no local model found, load from Hugging Face
        if self.model is None:
            try:
                print("No local model found. Loading RoBERTa-base model with custom classifier...")
                print("Note: Classifier layers are randomly initialized and need training for optimal performance")
                self.model = RobertaForSequenceClassification.from_pretrained(
                    "roberta-base", 
                    num_labels=3,
                    local_files_only=False
                )
                print("✓ Base model loaded with custom classifier")
                
                # Save the initialized model for future use
                if not os.path.exists("models/initialized_model"):
                    os.makedirs("models/initialized_model", exist_ok=True)
                    print("Saving initialized model for future use...")
                    self.model.save_pretrained("models/initialized_model")
                    self.tokenizer.save_pretrained("models/initialized_model")
                    print("✓ Model saved to models/initialized_model")
                
            except Exception as e:
                print(f"Error loading model: {e}")
                print("Falling back to rule-based assessment only")
                self.model = None
        
        if self.model:
            print(f"Model loaded from: {loaded_path or 'Hugging Face'}")
            if "trained" in str(loaded_path):
                print("✓ Using trained model - ready for inference!")
            else:
                print("⚠ Using untrained model - classifier layers are randomly initialized")
        else:
            print("⚠ No model available - using rule-based assessment only")
        
        self.labels = {0: "Weak", 1: "Medium", 2: "Strong"}
        self.common_passwords = self._load_common_passwords()

    def _load_common_passwords(self):
        """Load common weak passwords"""
        common_passwords = {
            '123456', 'password', '12345678', 'qwerty', '1234567890',
            '1234567', '123456789', '12345', '1234', '111111',
            '12345678910', '123123', '000000', 'abc123', 'password123',
            'admin', 'letmein', 'welcome', 'monkey', 'dragon',
            'master', 'sunshine', 'princess', 'qwertyuiop', 'admin123'
        }
        return common_passwords

    def predict_strength(self, password):
        """Predict password strength with exact requirements"""
        # First check length requirement
        if len(password) < 6 or len(password) > 8:
            return {
                'password': password,
                'strength': "Invalid",
                'confidence': 1.0,
                'probabilities': {'Weak': 0.0, 'Medium': 0.0, 'Strong': 0.0},
                'entropy': calculate_entropy(password),
                'brute_force_time': estimate_brute_force_time(password),
                'feedback': "Password must be 6-8 characters long."
            }
        
        # Rule-based assessment first
        strength, confidence, probabilities = self._exact_rule_based_assessment(password)
        
        # If model exists, blend with model prediction
        if self.model:
            try:
                # Move model to device if not already there
                if next(self.model.parameters()).device != self.device:
                    self.model = self.model.to(self.device)
                
                encoding = self.tokenizer(
                    [password],
                    truncation=True,
                    padding=True,
                    max_length=config["max_length"],
                    return_tensors="pt"
                )
                
                with torch.no_grad():
                    inputs = {
                        'input_ids': encoding['input_ids'].to(self.device),
                        'attention_mask': encoding['attention_mask'].to(self.device)
                    }
                    outputs = self.model(**inputs)
                    logits = outputs.logits
                    model_pred = torch.argmax(logits, dim=1).item()
                    model_probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
                
                # Blend rule-based and model predictions (70% rule, 30% model)
                probabilities = [
                    0.7 * probabilities[0] + 0.3 * model_probs[0],
                    0.7 * probabilities[1] + 0.3 * model_probs[1],
                    0.7 * probabilities[2] + 0.3 * model_probs[2]
                ]
                strength = np.argmax(probabilities)
                confidence = probabilities[strength]
                
            except Exception as e:
                print(f"Model prediction failed: {e}")
                print("Using rule-based assessment only")
        
        entropy = calculate_entropy(password)
        brute_force_time = estimate_brute_force_time(password)
        
        return {
            'password': password,
            'strength': self.labels[strength],
            'confidence': float(confidence),
            'probabilities': {
                'Weak': float(probabilities[0]),
                'Medium': float(probabilities[1]),
                'Strong': float(probabilities[2])
            },
            'entropy': entropy,
            'brute_force_time': brute_force_time,
            'feedback': self._generate_feedback(password, strength, entropy)
        }
    
    def _exact_rule_based_assessment(self, password):
        """Exact rules as specified by user"""
        # Weak passwords (0)
        if (len(password) < 6 or
            password.isnumeric() or
            password.isalpha() or
            password.lower() in self.common_passwords or
            password.lower() == password or
            not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 0, 0.99, [0.99, 0.01, 0.00]
        
        # Strong passwords (2)
        if (any(c.islower() for c in password) and
            any(c.isupper() for c in password) and
            any(c.isdigit() for c in password) and
            any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 2, 0.90, [0.05, 0.05, 0.90]
        
        # Medium passwords (1) - everything else
        return 1, 0.80, [0.10, 0.80, 0.10]
    
    def _generate_feedback(self, password, pred, entropy):
        """Generate feedback based on exact requirements"""
        feedback = []
        
        if pred == 0:  # Weak
            feedback.append("Your password is weak.")
            if password.isnumeric():
                feedback.append("Contains only numbers.")
            elif password.isalpha():
                feedback.append("Contains only letters.")
            elif password.lower() == password:
                feedback.append("No uppercase letters.")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                feedback.append("No special characters.")
        
        elif pred == 1:  # Medium
            feedback.append("Your password is medium strength.")
            missing = []
            if not any(c.islower() for c in password):
                missing.append("lowercase letters")
            if not any(c.isupper() for c in password):
                missing.append("uppercase letters")
            if not any(c.isdigit() for c in password):
                missing.append("numbers")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                missing.append("special characters")
            
            if missing:
                feedback.append(f"Add {' and '.join(missing)} to make it strong.")
        
        else:  # Strong
            feedback.append("Your password is strong!")
        
        return " ".join(feedback)

def main():
    print("Initializing Password Strength Detector...")
    detector = PasswordStrengthDetector(config["model_path"])
    
    print("\nPassword Strength Detection System (6-8 characters only)")
    print("Enter a password to check its strength (or 'quit' to exit):")
    
    test_passwords = [
        "12345", "abcdef", "P@ssw0", "123$ab", 
        "ABC123", "aBc$12", "123$$ABC", "aBc$%123"
    ]
    
    # Test mode (uncomment to verify behavior)
    # print("\nTest Results:")
    # for pwd in test_passwords:
    #     result = detector.predict_strength(pwd)
    #     print(f"\nPassword: {pwd} => {result['strength']}")
    #     print(f"Feedback: {result['feedback']}")
    
    # Interactive mode
    while True:
        password = input("\nPassword: ").strip()
        if password.lower() in ['quit', 'exit']:
            break
        
        result = detector.predict_strength(password)
        
        print("\nResults:")
        print(f"Password: {result['password']}")
        if result['strength'] == "Invalid":
            print(result['feedback'])
            continue
            
        print(f"Strength: {result['strength']} (confidence: {result['confidence']:.2f})")
        print(f"Probabilities - Weak: {result['probabilities']['Weak']:.4f}, Medium: {result['probabilities']['Medium']:.4f}, Strong: {result['probabilities']['Strong']:.4f}")
        print(f"Entropy: {result['entropy']:.2f} bits")
        print("\nEstimated cracking time:")
        for algo, time_est in result['brute_force_time'].items():
            print(f"  {algo}: {time_est}")
        print("\nRecommendations:")
        print(result['feedback'])

if __name__ == "__main__":
    main()