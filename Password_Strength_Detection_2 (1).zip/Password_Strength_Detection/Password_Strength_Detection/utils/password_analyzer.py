from math import log2

def calculate_entropy(password):
    """Calculate password entropy in bits"""
    char_sets = {
        'lower': set("abcdefghijklmnopqrstuvwxyz"),
        'upper': set("ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
        'digits': set("0123456789"),
        'symbols': set("""!@#$%^&*()_+-=[]{};':",./<>?`~""")
    }
    
    pool_size = 0
    for charset in char_sets.values():
        if any(c in charset for c in password):
            pool_size += len(charset)
    
    if pool_size == 0:  # If no characters matched (unlikely)
        pool_size = 26  # Assume lowercase only
    
    return len(password) * log2(pool_size)

def estimate_brute_force_time(password):
    """Estimate time to crack password via brute-force"""
    hash_speeds = {
        'MD5': 10**9,
        'SHA1': 10**8,
        'bcrypt': 10**3,
        'PBKDF2': 10**4,
        'scrypt': 10**2
    }
    
    entropy = calculate_entropy(password)
    possible_combinations = 2 ** entropy
    
    results = {}
    for algo, speed in hash_speeds.items():
        seconds = possible_combinations / speed
        results[algo] = format_time(seconds)
    
    return results

def format_time(seconds):
    """Convert seconds to human-readable time"""
    intervals = (
        ('years', 31536000),
        ('months', 2592000),
        ('weeks', 604800),
        ('days', 86400),
        ('hours', 3600),
        ('minutes', 60),
        ('seconds', 1)
    )
    
    result = []
    for name, count in intervals:
        value = seconds // count
        if value:
            seconds -= value * count
            result.append(f"{int(value)} {name}")
    
    return ", ".join(result[:2]) if result else "instant"