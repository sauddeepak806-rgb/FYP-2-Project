#!/usr/bin/env python3
"""
Password Strength Detection Model Training Script
Trains a RoBERTa model on password strength classification data
"""

import os
import torch
import pandas as pd
import numpy as np
from torch.utils.data import Dataset, DataLoader
from transformers import RobertaTokenizer, RobertaForSequenceClassification
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import json
import warnings

# Suppress warnings
warnings.filterwarnings("ignore")

class PasswordDataset(Dataset):
    """Dataset class for password strength classification"""
    
    def __init__(self, passwords, labels, tokenizer, max_length=128):
        self.passwords = passwords
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.passwords)
    
    def __getitem__(self, idx):
        password = str(self.passwords[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            password,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

def load_data(data_path):
    """Load and prepare password strength data"""
    print(f"Loading data from {data_path}...")
    
    if not os.path.exists(data_path):
        print(f"Error: Data file {data_path} not found!")
        return None, None
    
    try:
        df = pd.read_csv(data_path)
        print(f"Loaded {len(df)} password samples")
        
        # Check columns
        if 'password' not in df.columns or 'strength' not in df.columns:
            print("Error: Expected columns 'password' and 'strength'")
            return None, None
        
        # Check if strength is already numeric
        if df['strength'].dtype in ['int64', 'float64']:
            # Already numeric, just convert to int
            df['strength_numeric'] = df['strength'].astype(int)
            print("Strength column is already numeric")
        else:
            # Convert string labels to numeric
            strength_mapping = {'weak': 0, 'medium': 1, 'strong': 2}
            df['strength_numeric'] = df['strength'].str.lower().map(strength_mapping)
            print("Converted string strength labels to numeric")
        
        # Remove rows with invalid labels
        df = df.dropna(subset=['strength_numeric'])
        
        print(f"Valid samples: {len(df)}")
        print("Label distribution:")
        print(df['strength_numeric'].value_counts().sort_index())
        
        return df['password'].values, df['strength_numeric'].values
        
    except Exception as e:
        print(f"Error loading data: {e}")
        return None, None

def train_model(data_path, epochs=10, batch_size=32, learning_rate=2e-5):
    """Train the model on password strength data"""
    
    print("Starting model training...")
    
    # Load data
    passwords, labels = load_data(data_path)
    if passwords is None:
        return False
    
    # Split data (80% train, 20% validation)
    train_passwords, val_passwords, train_labels, val_labels = train_test_split(
        passwords, labels, test_size=0.2, random_state=42, stratify=labels
    )
    
    print(f"Training samples: {len(train_passwords)}")
    print(f"Validation samples: {len(val_passwords)}")
    
    # Load tokenizer and model
    print("Loading RoBERTa tokenizer and model...")
    tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
    model = RobertaForSequenceClassification.from_pretrained("roberta-base", num_labels=3)
    
    # Create datasets
    train_dataset = PasswordDataset(train_passwords, train_labels, tokenizer)
    val_dataset = PasswordDataset(val_passwords, val_labels, tokenizer)
    
    # Create dataloaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)
    
    # Setup training
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    
    print(f"Training on device: {device}")
    print(f"Epochs: {epochs}, Batch size: {batch_size}, Learning rate: {learning_rate}")
    
    optimizer = AdamW(model.parameters(), lr=learning_rate)
    total_steps = len(train_loader) * epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=total_steps)
    
    # Training loop
    best_val_acc = 0
    
    for epoch in range(epochs):
        print(f"\nEpoch {epoch + 1}/{epochs}")
        
        # Training
        model.train()
        total_train_loss = 0
        
        for batch_idx, batch in enumerate(train_loader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)
            
            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            
            total_train_loss += loss.item()
            
            # Progress indicator
            if (batch_idx + 1) % 100 == 0:
                print(f"  Batch {batch_idx + 1}/{len(train_loader)}")
        
        avg_train_loss = total_train_loss / len(train_loader)
        
        # Validation
        model.eval()
        total_val_loss = 0
        val_predictions = []
        val_true_labels = []
        
        print("  Running validation...")
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss
                total_val_loss += loss.item()
                
                logits = outputs.logits
                predictions = torch.argmax(logits, dim=1)
                
                val_predictions.extend(predictions.cpu().numpy())
                val_true_labels.extend(labels.cpu().numpy())
        
        avg_val_loss = total_val_loss / len(val_loader)
        val_accuracy = accuracy_score(val_true_labels, val_predictions)
        
        print(f"  Average training loss: {avg_train_loss:.4f}")
        print(f"  Average validation loss: {avg_val_loss:.4f}")
        print(f"  Validation accuracy: {val_accuracy:.4f}")
        
        # Save best model
        if val_accuracy > best_val_acc:
            best_val_acc = val_accuracy
            print(f"  New best validation accuracy: {best_val_acc:.4f}")
            
            # Save the trained model
            trained_model_path = "models/trained_model"
            os.makedirs(trained_model_path, exist_ok=True)
            model.save_pretrained(trained_model_path)
            tokenizer.save_pretrained(trained_model_path)
            print(f"  ✓ Best model saved to {trained_model_path}")
    
    print(f"\nTraining completed!")
    print(f"Best validation accuracy: {best_val_acc:.4f}")
    
    # Print final classification report
    print("\nFinal validation results:")
    print(classification_report(val_true_labels, val_predictions, 
                              target_names=['Weak', 'Medium', 'Strong']))
    
    return True

if __name__ == "__main__":
    # Load config
    with open('config.json') as f:
        config = json.load(f)
    
    print("=" * 60)
    print("PASSWORD STRENGTH DETECTION MODEL TRAINING")
    print("=" * 60)
    
    # Train the model
    success = train_model(
        data_path=config["data_path"],
        epochs=10,
        batch_size=32,
        learning_rate=2e-5
    )
    
    if success:
        print("\n" + "=" * 60)
        print("✓ MODEL TRAINING COMPLETED SUCCESSFULLY!")
        print("✓ You can now use the trained model for password strength prediction.")
        print("=" * 60)
    else:
        print("\n" + "=" * 60)
        print("✗ MODEL TRAINING FAILED!")
        print("=" * 60)
