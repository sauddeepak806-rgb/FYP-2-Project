# Password Strength Detection System

A machine learning-based password strength detection system using RoBERTa transformer model with rule-based fallback, enhanced with multiple datasets and comprehensive evaluation.

## Overview

This system combines a pre-trained RoBERTa model with rule-based assessment to classify password strength into three categories:
- **Weak (0)**: Passwords that don't meet basic security requirements
- **Medium (1)**: Passwords that meet some but not all security requirements  
- **Strong (2)**: Passwords that meet all security requirements

## Features

- **Hybrid Approach**: Combines ML predictions with rule-based assessment
- **Multiple Datasets**: Downloads and combines password strength datasets from Kaggle
- **Comprehensive Evaluation**: Provides detailed accuracy metrics across multiple datasets
- **Flexible Model Loading**: Automatically finds the best available model
- **Comprehensive Analysis**: Provides entropy, brute-force time estimates, and detailed feedback
- **Fallback Support**: Works even without trained models using rule-based assessment only
- **Visual Analytics**: Generates confusion matrices and accuracy comparison plots

## Installation

1. Install required dependencies:
```bash
pip install -r requirements.txt
```

2. (Optional) Set up Kaggle API for dataset downloads:
   - Go to https://www.kaggle.com/account
   - Click 'Create New API Token'
   - Download `kaggle.json`
   - Place it in `~/.kaggle/` directory

3. Ensure you have the required data files in the `data/` directory:
   - `labeled_passwords.csv` - Training data with columns: `password`, `strength`

## Quick Start

### Complete System Evaluation

Run the complete evaluation pipeline (downloads datasets, trains model, evaluates accuracy):

```bash
python run_complete_evaluation.py
```

This will:
1. Download multiple password strength datasets from Kaggle
2. Combine and clean the datasets
3. Train an enhanced RoBERTa model
4. Evaluate accuracy across multiple datasets
5. Generate comprehensive reports and visualizations

### Individual Components

#### Download Datasets
```bash
python download_datasets.py
```

#### Train Enhanced Model
```bash
python train_enhanced_model.py
```

#### Evaluate System Accuracy
```bash
python evaluate_system.py
```

### Basic Usage

Run the main console application:
```bash
python main.py
```

### GUI Interface

Run the graphical user interface:
```bash
python gui_interface.py
```

**Features of the GUI:**
- Modern Tkinter-based interface
- Visual color-coded strength indicators
- Real-time password analysis
- Progress bars and probability visualizations
- Detailed analysis reports
- Show/Hide password toggle

For more details, see RUN_GUI.md

**Quick Test:**
Before running the GUI, verify everything works:
```bash
python test_gui.py
```

## Dataset Sources

The system downloads and combines multiple password strength datasets:

1. **Password Strength Classifier** (bhavikardeshna/password-strength-classifier)
2. **Password Strength Dataset** (utkarshx27/password-strength-dataset)
3. **Password Strength Classification** (bhavikardeshna/password-strength-classification)
4. **Password Strength Prediction** (bhavikardeshna/password-strength-prediction)
5. **Original Dataset** (your existing labeled_passwords.csv)

## Model Setup

The system automatically handles model loading with the following priority:

1. **Enhanced Trained Model** (`models/enhanced_trained_model/`) - Best performance
2. **Trained Model** (`models/trained_model/`) - Standard trained model
3. **Config-specified Model** (from `config.json`)
4. **Initialized Model** (`models/initialized_model/`) - Randomly initialized classifier
5. **Hugging Face Base Model** - Downloads and initializes on first run

### Initializing the Model

To create an initialized model (required before training):
```bash
cd models
python initialize_model.py
```

### Training the Model

To train the model on your password strength data:
```bash
python train_model.py
```

To train the enhanced model on combined datasets:
```bash
python train_enhanced_model.py
```

**Note**: Training requires labeled password data in `data/labeled_passwords.csv` with columns:
- `password`: The actual password string
- `strength`: Label (weak/medium/strong)

## Configuration

Edit `config.json` to customize:
- `model_path`: Path to preferred model
- `data_path`: Path to training data
- `max_length`: Maximum token length for passwords
- `batch_size`: Training batch size
- `use_model_prediction`: Enable/disable ML predictions
- `rule_model_blend_ratio`: Weight for rule-based vs ML predictions

## Evaluation Results

The system provides comprehensive evaluation metrics:

### Accuracy Metrics
- **Overall Accuracy**: System performance across all datasets
- **Per-Dataset Accuracy**: Individual dataset performance
- **Precision, Recall, F1-Score**: Detailed classification metrics
- **Confusion Matrices**: Visual representation of predictions

### Generated Files
- `detailed_evaluation_report.json` - Complete evaluation results
- `accuracy_comparison.png` - Accuracy comparison across datasets
- `evaluation_plots/` - Confusion matrices for each dataset
- `training_history.png` - Training progress visualization
- `confusion_matrix.png` - Test set confusion matrix

## Understanding the Warning

The warning you encountered:
```
Some weights of RobertaForSequenceClassification were not initialized from the model checkpoint at roberta-base and are newly initialized: ['classifier.dense.bias', 'classifier.dense.weight', 'classifier.out_proj.bias', 'classifier.out_proj.weight']
```

**This is normal and expected behavior!** Here's why:

1. **Base Model**: `roberta-base` is a general-purpose language model trained on text data
2. **Custom Classifier**: Password strength classification requires a custom classifier head
3. **New Layers**: The classifier layers (`dense` and `out_proj`) are added specifically for this task
4. **Random Initialization**: These new layers start with random weights

### Solutions

1. **Use the System as-is**: The warning is harmless and the system works with rule-based fallback
2. **Train the Model**: Use `train_enhanced_model.py` to train the classifier layers on combined data
3. **Suppress the Warning**: Already handled in the code with `warnings.filterwarnings()`

## Model Architecture

```
RoBERTa Base Encoder (frozen)
    ↓
Custom Classifier Head (trainable)
    ↓
3-class Output (Weak/Medium/Strong)
```

## Performance

- **Rule-based Only**: Fast, deterministic, no ML dependencies
- **Hybrid Mode**: Combines rule-based logic with ML predictions for better accuracy
- **ML Only**: Requires trained model, highest potential accuracy
- **Enhanced Model**: Trained on multiple datasets for improved generalization

## Troubleshooting

### Common Issues

1. **CUDA Out of Memory**: Reduce `batch_size` in training
2. **Model Loading Errors**: Check file paths and permissions
3. **Training Failures**: Verify data format and labels
4. **Kaggle API Errors**: Check kaggle.json configuration

### Debug Mode

Enable verbose logging by modifying the main script or check console output for detailed information.

## File Structure

```
Password_Strength_Detection/
├── main.py                      # Main console application
├── gui_interface.py             # GUI application
├── test_gui.py                  # GUI testing script
├── run_complete_evaluation.py   # Complete evaluation pipeline
├── download_datasets.py         # Dataset downloader
├── train_enhanced_model.py      # Enhanced model training
├── evaluate_system.py           # System evaluation
├── config.json                  # Configuration file
├── RUN_GUI.md                   # GUI user guide
├── data/                        # Data directory
│   ├── labeled_passwords.csv
│   ├── combined_passwords.csv   # Combined datasets
│   ├── train_passwords.csv      # Training split
│   ├── val_passwords.csv        # Validation split
│   └── test_passwords.csv       # Test split
├── models/                      # Model directory
│   ├── initialized_model/       # Auto-created
│   ├── trained_model/           # After training
│   └── enhanced_trained_model/  # Enhanced model
├── utils/                       # Utility functions
│   ├── password_analyzer.py
│   └── dataset_creator.py
├── evaluation_plots/            # Generated visualizations
├── requirements.txt             # Dependencies
├── training_results.json        # Training results
└── detailed_evaluation_report.json # Evaluation results
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review the console output for error messages
3. Ensure all dependencies are properly installed
4. Verify data file formats and paths
5. Check Kaggle API configuration if using dataset downloads
