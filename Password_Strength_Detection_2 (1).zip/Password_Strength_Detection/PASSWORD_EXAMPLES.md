# Password Examples for Testing

## Medium Strength Passwords

Copy and paste these into your GUI for testing:

```
Pass123        (missing special characters) → MEDIUM
str0ng#        (missing uppercase) → MEDIUM  
PASS@12        (missing lowercase) → MEDIUM
MyPass1        (missing special) → MEDIUM
```

## Complete Demo Sequence

1. **Weak**: `password` → 🔴 WEAK
2. **Medium**: `Pass123` → 🟡 MEDIUM  
3. **Strong**: `P@ss123!` → 🟢 STRONG







