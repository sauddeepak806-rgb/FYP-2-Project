# Password Strength Detection GUI

## Overview
This is a separate graphical user interface (GUI) for the Password Strength Detection system built with Tkinter.

## Features
- **Modern UI**: Clean and intuitive graphical interface
- **Real-time Analysis**: Analyze passwords with detailed feedback
- **Visual Indicators**: 
  - Color-coded strength indicators (Red/Yellow/Green)
  - Progress bar showing password strength
  - Probability distribution bars
- **Detailed Reports**: 
  - Strength classification (Weak/Medium/Strong)
  - Confidence scores
  - Entropy calculations
  - Estimated cracking times
  - Personalized recommendations
- **Show/Hide Password**: Toggle password visibility

## Requirements
All dependencies from `requirements.txt` are needed:
```bash
pip install -r requirements.txt
```

**Note**: Tkinter comes pre-installed with most Python distributions. If you encounter issues, you may need to install it separately:
- Windows: Usually pre-installed
- Ubuntu/Debian: `sudo apt-get install python3-tk`
- macOS: Usually pre-installed

## How to Run

### Option 1: Run the GUI directly
```bash
python gui_interface.py
```

### Option 2: Run from any directory
```bash
cd C:\Users\Acer\OneDrive\Desktop\Password_Strength_Detection
python gui_interface.py
```

## Usage Instructions

1. **Launch the Application**: Run `python gui_interface.py`
2. **Enter Password**: Type a password (6-8 characters) in the input field
3. **Analyze**: Click the "Analyze Password" button or the analysis will run automatically
4. **View Results**: See detailed analysis including:
   - Strength level (Weak/Medium/Strong)
   - Probability distribution
   - Entropy in bits
   - Estimated cracking times for different attack methods
   - Personalized recommendations
5. **Toggle Visibility**: Check the "Show" checkbox to reveal/hide the password

## Password Requirements
- **Length**: Must be between 6-8 characters
- **Weak**: Contains only numbers, only letters, no uppercase, or no special characters
- **Medium**: Meets some but not all strong requirements
- **Strong**: Contains lowercase letters, uppercase letters, numbers, AND special characters

## System Architecture
- Uses the same `PasswordStrengthDetector` class from `main.py`
- Blends rule-based assessment (70%) with RoBERTa model predictions (30%)
- GPU acceleration supported (automatically uses CUDA if available)

## Troubleshooting

### GUI doesn't open
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check Python version: Requires Python 3.7+
- Try running from terminal to see error messages

### Model loading errors
- First run will download RoBERTa model from Hugging Face
- Ensure internet connection on first launch
- Model will be cached for future use

### Performance issues
- Large models may take a few seconds to load initially
- GPU acceleration speeds up inference significantly
- Console window will show loading progress

## File Structure
```
Password_Strength_Detection/
├── gui_interface.py          # Main GUI application
├── main.py                   # Console interface (original)
├── config.json               # Configuration file
├── models/
│   └── initialized_model/    # Model files
└── requirements.txt          # Python dependencies
```

## Comparison: GUI vs Console Interface

| Feature | GUI (`gui_interface.py`) | Console (`main.py`) |
|---------|-------------------------|---------------------|
| User Interface | Graphical (Tkinter) | Text-based terminal |
| Visual Feedback | Progress bars, colors | Text only |
| Best For | End users, demos | Developers, automation |
| Dependencies | + Tkinter | Minimal |
| Learning Curve | Easy | Moderate |

## Future Enhancements
Potential improvements for the GUI:
- Batch password analysis
- Export reports to PDF/CSV
- Password history
- Customizable strength criteria
- Real-time strength updates as you type
- Integration with password managers

## Support
For issues or questions, refer to the main README.md or check the console output for error messages.

