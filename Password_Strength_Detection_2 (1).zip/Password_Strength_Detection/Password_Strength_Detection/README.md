# Password Strength Detection System Using RoBERTa

## System Requirements
- Python 3.8+
- VS Code (recommended)
- GPU (recommended for training)

## Setup Instructions

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt