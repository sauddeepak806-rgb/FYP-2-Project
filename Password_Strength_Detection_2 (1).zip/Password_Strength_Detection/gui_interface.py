import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import torch
from transformers import RobertaTokenizer, RobertaForSequenceClassification
import numpy as np
import json
import os
import warnings
import math
import string

# Suppress warnings
warnings.filterwarnings("ignore", message="Some weights of RobertaForSequenceClassification were not initialized from the model checkpoint")

# Load configuration
with open('config.json') as f:
    config = json.load(f)

class PasswordStrengthGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Strength Detection System")
        self.root.geometry("800x700")
        self.root.configure(bg="#f0f0f0")
        
        # Initialize detector
        self.detector = None
        self.init_detector()
        
        # Create UI
        self.create_widgets()
        
    def init_detector(self):
        """Initialize the password strength detector"""
        try:
            self.detector = PasswordStrengthDetector(config["model_path"])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to initialize detector: {e}")
    
    def create_widgets(self):
        """Create and arrange all UI widgets"""
        
        # Main title
        title_frame = tk.Frame(self.root, bg="#2c3e50", height=80)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(
            title_frame, 
            text="🔒 Password Strength Detection System",
            font=("Arial", 20, "bold"),
            bg="#2c3e50",
            fg="white"
        )
        title_label.pack(pady=20)
        
        # Info label
        info_label = tk.Label(
            self.root,
            text="Enter a password (6-8 characters) to check its strength",
            font=("Arial", 10),
            bg="#f0f0f0",
            fg="#555"
        )
        info_label.pack(pady=10)
        
        # Input frame
        input_frame = tk.Frame(self.root, bg="#f0f0f0")
        input_frame.pack(pady=20, padx=20, fill=tk.X)
        
        self.password_var = tk.StringVar()
        self.password_var.trace("w", lambda *args: self.on_password_change())
        
        password_entry = tk.Entry(
            input_frame,
            textvariable=self.password_var,
            font=("Arial", 14),
            width=40,
            show="•"
        )
        password_entry.pack(side=tk.LEFT, padx=5)
        
        # Show/Hide password button
        self.show_password_var = tk.BooleanVar()
        show_password_check = tk.Checkbutton(
            input_frame,
            text="Show",
            variable=self.show_password_var,
            command=lambda: password_entry.config(show="" if self.show_password_var.get() else "•"),
            bg="#f0f0f0",
            font=("Arial", 10)
        )
        show_password_check.pack(side=tk.LEFT, padx=5)
        
        # Analyze button
        analyze_btn = tk.Button(
            input_frame,
            text="Analyze Password",
            command=self.analyze_password,
            bg="#3498db",
            fg="white",
            font=("Arial", 12, "bold"),
            cursor="hand2",
            padx=20,
            pady=10
        )
        analyze_btn.pack(side=tk.LEFT, padx=10)
        
        # Results frame
        results_frame = tk.LabelFrame(
            self.root,
            text="Results",
            font=("Arial", 12, "bold"),
            bg="#f0f0f0",
            padx=20,
            pady=15
        )
        results_frame.pack(pady=10, padx=20, fill=tk.BOTH, expand=True)
        
        # Strength indicator
        self.strength_label = tk.Label(
            results_frame,
            text="Enter a password to analyze",
            font=("Arial", 16, "bold"),
            bg="#f0f0f0",
            fg="#555"
        )
        self.strength_label.pack(pady=10)
        
        # Progress bar
        self.progress = ttk.Progressbar(
            results_frame,
            mode='determinate',
            length=400
        )
        self.progress.pack(pady=10)
        
        # Details text area
        self.details_text = scrolledtext.ScrolledText(
            results_frame,
            height=15,
            font=("Arial", 10),
            bg="#ffffff",
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.details_text.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Status bar
        status_frame = tk.Frame(self.root, bg="#34495e", height=30)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        status_frame.pack_propagate(False)
        
        self.status_label = tk.Label(
            status_frame,
            text="Ready",
            bg="#34495e",
            fg="white",
            font=("Arial", 9)
        )
        self.status_label.pack(side=tk.LEFT, padx=10, pady=5)
    
    def on_password_change(self):
        """Handle password field changes"""
        password = self.password_var.get()
        if len(password) == 0:
            self.strength_label.config(text="Enter a password to analyze", fg="#555")
            self.progress['value'] = 0
            self.details_text.config(state=tk.NORMAL)
            self.details_text.delete(1.0, tk.END)
            self.details_text.config(state=tk.DISABLED)
    
    def analyze_password(self):
        """Analyze the entered password"""
        password = self.password_var.get()
        
        if not password:
            messagebox.showwarning("Warning", "Please enter a password")
            return
        
        try:
            result = self.detector.predict_strength(password)
            self.display_results(result)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to analyze password: {e}")
    
    def display_results(self, result):
        """Display analysis results"""
        # Clear previous results
        self.details_text.config(state=tk.NORMAL)
        self.details_text.delete(1.0, tk.END)
        
        # Get strength and color
        strength = result['strength']
        
        if strength == "Invalid":
            self.strength_label.config(text="❌ Invalid Password", fg="#e74c3c")
            self.progress['value'] = 0
            self.details_text.insert(tk.END, f"\n{result['feedback']}\n\n")
            self.details_text.config(state=tk.DISABLED)
            return
        
        # Set strength label and color
        strength_colors = {
            "Weak": "#e74c3c",
            "Medium": "#f39c12",
            "Strong": "#27ae60"
        }
        
        strength_icons = {
            "Weak": "🔴",
            "Medium": "🟡",
            "Strong": "🟢"
        }
        
        color = strength_colors[strength]
        icon = strength_icons[strength]
        
        self.strength_label.config(
            text=f"{icon} Strength: {strength}",
            fg=color
        )
        
        # Set progress bar
        strength_values = {"Weak": 33, "Medium": 66, "Strong": 100}
        self.progress['value'] = strength_values[strength]
        
        # Display detailed results
        self.details_text.insert(tk.END, "=" * 50 + "\n")
        self.details_text.insert(tk.END, "PASSWORD ANALYSIS REPORT\n", "header")
        self.details_text.insert(tk.END, "=" * 50 + "\n\n")
        
        # Password
        self.details_text.insert(tk.END, "Password: ")
        self.details_text.insert(tk.END, f"{result['password']}\n\n", "password")
        
        # Strength
        self.details_text.insert(tk.END, f"Strength: ")
        self.details_text.insert(tk.END, f"{result['strength']}\n", "bold")
        self.details_text.insert(tk.END, f"Confidence: {result['confidence']:.2%}\n\n")
        
        # Probabilities
        self.details_text.insert(tk.END, "Probability Distribution:\n", "bold")
        for label, prob in result['probabilities'].items():
            bar_length = int(prob * 40)
            bar = "█" * bar_length + "░" * (40 - bar_length)
            self.details_text.insert(tk.END, f"  {label:8s}: {prob:.4f} {bar}\n")
        
        # Entropy
        self.details_text.insert(tk.END, f"\nEntropy: {result['entropy']:.2f} bits\n\n")
        
        # Brute force time
        self.details_text.insert(tk.END, "Estimated Cracking Time:\n", "bold")
        for algo, time_est in result['brute_force_time'].items():
            self.details_text.insert(tk.END, f"  {algo}: {time_est}\n")
        
        # Feedback
        self.details_text.insert(tk.END, f"\nRecommendations:\n", "bold")
        self.details_text.insert(tk.END, f"{result['feedback']}\n")
        
        # Configure text tags
        self.details_text.tag_config("header", font=("Arial", 11, "bold"), foreground="#2c3e50")
        self.details_text.tag_config("bold", font=("Arial", 10, "bold"))
        self.details_text.tag_config("password", font=("Courier", 10, "bold"), foreground="#3498db")
        
        self.details_text.config(state=tk.DISABLED)
        
        # Update status
        self.status_label.config(text="Analysis complete")

# Include the PasswordStrengthDetector class and helper functions from main.py
def calculate_entropy(password):
    """Calculate password entropy in bits"""
    if not password:
        return 0
    
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()_+-=[]{};':\",./<>?`~"
    
    charset_size = 0
    if any(c in lowercase for c in password):
        charset_size += len(lowercase)
    if any(c in uppercase for c in password):
        charset_size += len(uppercase)
    if any(c in digits for c in password):
        charset_size += len(digits)
    if any(c in special for c in password):
        charset_size += len(special)
    
    if charset_size == 0:
        return 0
    
    entropy = len(password) * math.log2(charset_size)
    return round(entropy, 2)

def estimate_brute_force_time(password):
    """Estimate brute force attack time for different attack methods"""
    if not password:
        return {"Dictionary": "Instant", "Brute Force": "Instant", "Advanced": "Instant"}
    
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()_+-=[]{};':\",./<>?`~"
    
    charset_size = 0
    if any(c in lowercase for c in password):
        charset_size += len(lowercase)
    if any(c in uppercase for c in password):
        charset_size += len(uppercase)
    if any(c in digits for c in password):
        charset_size += len(digits)
    if any(c in special for c in password):
        charset_size += len(special)
    
    if charset_size == 0:
        return {"Dictionary": "Instant", "Brute Force": "Instant", "Advanced": "Instant"}
    
    combinations = charset_size ** len(password)
    attempts_per_second = 1_000_000_000
    seconds = combinations / attempts_per_second
    
    if seconds < 1:
        time_str = "Instant"
    elif seconds < 60:
        time_str = f"{seconds:.0f} seconds"
    elif seconds < 3600:
        time_str = f"{seconds/60:.0f} minutes"
    elif seconds < 86400:
        time_str = f"{seconds/3600:.0f} hours"
    elif seconds < 31536000:
        time_str = f"{seconds/86400:.0f} days"
    else:
        time_str = f"{seconds/31536000:.0f} years"
    
    if len(password) <= 6:
        dict_time = "Seconds to minutes"
    elif len(password) <= 8:
        dict_time = "Minutes to hours"
    else:
        dict_time = "Hours to days"
    
    return {
        "Dictionary Attack": dict_time,
        "Brute Force": time_str,
        "Advanced Attack": f"{time_str} (estimated)"
    }

class PasswordStrengthDetector:
    def __init__(self, model_path=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
        
        model_paths = [
            "models/trained_model",
            model_path,
            "models/initialized_model"
        ]
        
        self.model = None
        loaded_path = None
        
        for path in model_paths:
            if path and os.path.exists(path) and os.path.isdir(path):
                try:
                    self.model = RobertaForSequenceClassification.from_pretrained(path)
                    loaded_path = path
                    break
                except Exception as e:
                    continue
        
        if self.model is None:
            try:
                self.model = RobertaForSequenceClassification.from_pretrained(
                    "roberta-base",
                    num_labels=3,
                    local_files_only=False
                )
                if not os.path.exists("models/initialized_model"):
                    os.makedirs("models/initialized_model", exist_ok=True)
                    self.model.save_pretrained("models/initialized_model")
                    self.tokenizer.save_pretrained("models/initialized_model")
            except Exception as e:
                self.model = None
        
        self.labels = {0: "Weak", 1: "Medium", 2: "Strong"}
        self.common_passwords = self._load_common_passwords()

    def _load_common_passwords(self):
        common_passwords = {
            '123456', 'password', '12345678', 'qwerty', '1234567890',
            '1234567', '123456789', '12345', '1234', '111111',
            '12345678910', '123123', '000000', 'abc123', 'password123',
            'admin', 'letmein', 'welcome', 'monkey', 'dragon',
            'master', 'sunshine', 'princess', 'qwertyuiop', 'admin123'
        }
        return common_passwords

    def predict_strength(self, password):
        if len(password) < 6 or len(password) > 8:
            return {
                'password': password,
                'strength': "Invalid",
                'confidence': 1.0,
                'probabilities': {'Weak': 0.0, 'Medium': 0.0, 'Strong': 0.0},
                'entropy': calculate_entropy(password),
                'brute_force_time': estimate_brute_force_time(password),
                'feedback': "Password must be 6-8 characters long."
            }
        
        strength, confidence, probabilities = self._exact_rule_based_assessment(password)
        
        if self.model:
            try:
                if next(self.model.parameters()).device != self.device:
                    self.model = self.model.to(self.device)
                
                encoding = self.tokenizer(
                    [password],
                    truncation=True,
                    padding=True,
                    max_length=config["max_length"],
                    return_tensors="pt"
                )
                
                with torch.no_grad():
                    inputs = {
                        'input_ids': encoding['input_ids'].to(self.device),
                        'attention_mask': encoding['attention_mask'].to(self.device)
                    }
                    outputs = self.model(**inputs)
                    logits = outputs.logits
                    model_probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
                
                probabilities = [
                    0.7 * probabilities[0] + 0.3 * model_probs[0],
                    0.7 * probabilities[1] + 0.3 * model_probs[1],
                    0.7 * probabilities[2] + 0.3 * model_probs[2]
                ]
                strength = np.argmax(probabilities)
                confidence = probabilities[strength]
            except Exception as e:
                pass
        
        entropy = calculate_entropy(password)
        brute_force_time = estimate_brute_force_time(password)
        
        return {
            'password': password,
            'strength': self.labels[strength],
            'confidence': float(confidence),
            'probabilities': {
                'Weak': float(probabilities[0]),
                'Medium': float(probabilities[1]),
                'Strong': float(probabilities[2])
            },
            'entropy': entropy,
            'brute_force_time': brute_force_time,
            'feedback': self._generate_feedback(password, strength, entropy)
        }
    
    def _exact_rule_based_assessment(self, password):
        if (len(password) < 6 or
            password.isnumeric() or
            password.isalpha() or
            password.lower() in self.common_passwords or
            password.lower() == password or
            not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 0, 0.99, [0.99, 0.01, 0.00]
        
        if (any(c.islower() for c in password) and
            any(c.isupper() for c in password) and
            any(c.isdigit() for c in password) and
            any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password)):
            return 2, 0.90, [0.05, 0.05, 0.90]
        
        return 1, 0.80, [0.10, 0.80, 0.10]
    
    def _generate_feedback(self, password, pred, entropy):
        feedback = []
        
        if pred == 0:
            feedback.append("Your password is weak.")
            if password.isnumeric():
                feedback.append("Contains only numbers.")
            elif password.isalpha():
                feedback.append("Contains only letters.")
            elif password.lower() == password:
                feedback.append("No uppercase letters.")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                feedback.append("No special characters.")
        
        elif pred == 1:
            feedback.append("Your password is medium strength.")
            missing = []
            if not any(c.islower() for c in password):
                missing.append("lowercase letters")
            if not any(c.isupper() for c in password):
                missing.append("uppercase letters")
            if not any(c.isdigit() for c in password):
                missing.append("numbers")
            if not any(c in """!@#$%^&*()_+-=[]{};':",./<>?`~""" for c in password):
                missing.append("special characters")
            
            if missing:
                feedback.append(f"Add {' and '.join(missing)} to make it strong.")
        
        else:
            feedback.append("Your password is strong!")
        
        return " ".join(feedback)

def main():
    root = tk.Tk()
    app = PasswordStrengthGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()

